function clearErrors() {
    let errors = document.getElementsByClassName('formerror');
    for (let item of errors) {
        item.innerHTML = "";
    }
}

function seterror(id, error) {
    // Sets error inside tag of id 
    let element = document.getElementById(id);
    element.getElementsByClassName('formerror')[0].innerHTML = error;
}

function validateForm() {
    let returnval = true;
    clearErrors();

    // Perform validation and if validation fails, set the value of returnval to false
    let fname = document.forms['myForm']["fname"].value;
    if (fname.length < 5) {
        seterror("fname", "*Length of first name is too short");
        returnval = false;
    }

    if (fname.length == 0) {
        seterror("fname", "*Length of first name cannot be zero!");
        returnval = false;
    }

    let lname = document.forms['myForm']["lname"].value;
    if (lname.length < 5) {
        seterror("lname", "*Length of last name is too short");
        returnval = false;
    }

    if (lname.length == 0) {
        seterror("lname", "*Length of last name cannot be zero!");
        returnval = false;
    }

    let email = document.forms['myForm']["email"].value;
    if (email.length > 15) {
        seterror("email", "*Email length is too long");
        returnval = false;
    }

    let password = document.forms['myForm']["password"].value;
    let passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;
    if (!passwordRegex.test(password)) {
        seterror("password", "*Password should be at least 6 characters long, contain at least one letter, one number, one special character, and one uppercase letter");
        returnval = false;
    }

    return returnval;
}
