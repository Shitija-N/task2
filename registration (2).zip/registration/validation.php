<?php

$errors="";
if(empty($_POST["fname"])){
    $errors="First Name is Required";

}
else if (!filter_var($_POST["email"],FILTER_VALIDATE_EMAIL)){
        echo "Enter valid email";
}
else if (strlen($_POST["password"]) < 8) {
    echo "Password must be at least 8 characters" ;
}
 else if ( ! preg_match("/[a-z]/i", $_POST["password"])) {
    echo "Password must contain at least one letter" ;
}
 else if ( ! preg_match("/[0-9]/", $_POST["password"])) {
    echo "Password must contain at least one number" ;
}

?>
