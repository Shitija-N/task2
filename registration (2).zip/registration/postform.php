<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare("INSERT INTO posts (user_id, name, description, date) VALUES (:user_id, :name, :description, :date)");
    $stmt->execute(['user_id' => $user_id, 'name' => $name, 'description' => $description, 'date' => $date]);

    header("Location: posts_list.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Post</title>
</head>
<body>
    <form method="post">
        <input type="text" name="name" placeholder="Name" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="date" name="date" required>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
