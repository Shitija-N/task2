<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
   
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="frontend_validation.js"></script>

</head>

<body>
  
   
</nav>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Form</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Features</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pricing</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
        </li>
        </ul>
    </div>
    </div>
</nav>

    <div class="container" id="signup" style="display:none;">
    <h1 class="form-title">Register</h1>
    <form id="signupForm"  name="myForm" onsubmit="return validateForm()" method="post">
        <div class="input-group">
            <i class="fas fa-user"></i>
            <input type="text" name="fname" id="fname" placeholder="First Name" autocomplete="off">
            <b><span class="formerror"></span></b>
            <label for="fname">First Name</label>
            <p id="test" style="display: none; color: red;">Please enter your first name</p>
        </div>
        <div class="input-group">
        <i class="fas fa-user"></i>
        <input type="text" name="lname" id="lname" placeholder="Last Name" autocomplete="off">
        <label for="lname">Last Name</label>
        <div id="test2"></div>
       </div>

        <div class="input-group">
        <i class="fas fa-envelope"></i>
        <input type="email" name="email" id="email" placeholder="Email" autocomplete="off">
        <label for="email">Email</label>
        <div id="test1"></div>
        </div>
        <div class="input-group">
            <i class="fas fa-lock"></i>
            <input type="password"  name="password" id="password" placeholder="Password" autocomplete="off">

            <label for="password">Password</label>
            
        </div>
        <div class="btn>
        <input type="submit" class="btn" value="Sign Up" name="signUp">
        
       
      </form>
      
      </div>
       <input type="submit" class="btn" value="Sign Up" name="signUp">
       
      </form>
      
      <div class="icons">
        <i class="fab fa-google"></i>
        <i class="fab fa-facebook"></i>
      </div>
      <div class="links">
        <p>Already Have Account ?</p>
        <button id="signInButton">Sign In</button>
      </div>
    </div>

    <div class="container" id="signIn">
        <h1 class="form-title">Sign In</h1>
        <form method="post" action="register.php">
          <div class="input-group">
              <i class="fas fa-envelope"></i>
              <input type="email"  name="email" id="email1" placeholder="Email" required>
              <label for="email">Email</label>
          </div>
          <div class="input-group">
              <i class="fas fa-lock"></i>
              <input type="password" name="password" id="password1" placeholder="Password" required>
              <label for="password">Password</label>
          </div>
          <p class="recover">
            <a href="#">Recover Password</a>
          </p>
          <div id="error_msg"></div>
          <input type="submit" class="btn" value="Sign In" name="signIn">
         <br><br><br>
        </form>
       
        <div class="icons">
          <i class="fab fa-google"></i>
          <i class="fab fa-facebook"></i>
        </div>
        <div class="links">
          <p>Don't have account yet?</p>
          <button id="signUpButton">Sign Up</button>
        </div>
      </div>
      <script src="script.js"></script>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
    $('#signupForm').submit(function(event) {
        event.preventDefault(); 

        if (validate()) {
            var formData = $(this).serialize(); 
            $.ajax({
                url: "register.php",
                type: "POST",
                data: formData,
                success: function(response) {
                    console.log('Form submitted successfully');
                    console.log(response);
                    
                },
                error: function(xhr, status, error) {
                    console.log('Form submission failed');
                    console.log(error);
                    
                }
            });
        }
    });

    $('#signUpButton').click(function() {
        $('#signIn').hide();
        $('#signup').show();
    });

    $('#signInButton').click(function() {
        $('#signup').hide();
        $('#signIn').show();
    });

    function validate() {
        let valid = true;
        let fname = $("#fname").val();
        let lname = $("#lname").val();
        let email = $("#email").val();
        let pass = $("#password").val();

        if (fname == '') {
            $("#test").css("display", "block");
            valid = false;
        } else {
            $("#test").css("display", "none");
        }

        if (lname == '') {
            $("#test2").html("<p>Please enter your last name*</p>").css("color", "red");
            valid = false;
        } else {
            $("#test2").html("");
        }

        if (email.length == 0) {
            $("#test1").html("<p>Please enter a valid email*</p>").css("color", "red");
            valid = false;
        } else {
            $("#test1").html("");
        }

        if (pass.length == 0) {
            $("#test3").html("<p>Please enter a valid password*</p>").css("color", "red");
            valid = false;
        } else {
            $("#test3").html("");
        }

        return valid;
    }
});
</script>
</html>
